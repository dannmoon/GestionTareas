using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Proyecto.Models;

namespace Proyecto.Controllers
{
    public class EmpController : Controller
    {
        private readonly ILogger<EmpController> _logger;

        private readonly BDS_Gestion_tareasContext _db;

        public EmpController(ILogger<EmpController> logger, BDS_Gestion_tareasContext  BDS_Gestion_tareasContext)
        {
            _logger = logger;
            _db = BDS_Gestion_tareasContext;
        }
public IActionResult Index()
        {
            return View(_db.TblTareas.ToList());
        }

        
    }
}