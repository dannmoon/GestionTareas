using System;
using Microsoft.AspNetCore.Mvc;

namespace Proyecto.Controllers
{
    public class AppController : Controller{

public IActionResult Index()
        {
            return View();
        }

        
    }
}