using System;
using Microsoft.AspNetCore.Mvc;

namespace Proyecto.Controllers
{
    public class UsuarioController : Controller{

public IActionResult Index()
        {
            return View();
        }

        
    }
}