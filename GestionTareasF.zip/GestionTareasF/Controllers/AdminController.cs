using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Proyecto.Models;

namespace Proyecto.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;

        private readonly BDS_Gestion_tareasContext _db;

        public AdminController(ILogger<AdminController> logger, BDS_Gestion_tareasContext  BDS_Gestion_tareasContext)
        {
            _logger = logger;
            _db = BDS_Gestion_tareasContext;
        }

    

public IActionResult Index()
        {
            return View(_db.TblUsuarios.ToList());
        }
        public IActionResult Empresas()
        {
            return View(_db.TblEmpresas.ToList());
        }
        public IActionResult Roles()
        {
            return View(_db.TblRols.ToList());
        }
        public IActionResult Tareas()
        {
            return View(_db.TblTareas.ToList());
        }

        
    }
}