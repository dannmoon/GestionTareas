using System;
using Microsoft.AspNetCore.Mvc;

namespace Proyecto.Controllers
{
    public class UserController : Controller{

public IActionResult Index()
        {
            return View();
        }

        public IActionResult Password()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
        
    }
}