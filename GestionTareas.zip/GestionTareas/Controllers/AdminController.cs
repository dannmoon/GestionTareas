using System;
using Microsoft.AspNetCore.Mvc;

namespace Proyecto.Controllers
{
    public class AdminController : Controller{

public IActionResult Index()
        {
            return View();
        }
public IActionResult Empresas()
        {
            return View();
        }
        public IActionResult Roles()
        {
            return View();
        }
public IActionResult Tareas()
        {
            return View();
        }



        
    }
}